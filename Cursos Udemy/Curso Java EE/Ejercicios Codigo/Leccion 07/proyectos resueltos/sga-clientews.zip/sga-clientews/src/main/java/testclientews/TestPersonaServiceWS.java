package testclientews;

import java.util.List;

import javax.xml.ws.BindingProvider;

import clientesga.ws.Persona;
import clientesga.ws.PersonaServiceImplService;
import clientesga.ws.PersonaServiceWS;

public class TestPersonaServiceWS {

    public static void main(String[] args) {
    	
    	System.out.println("Ejecutando Servicio Listar Personas WS\n");
    	
        PersonaServiceWS personaService = new PersonaServiceImplService().getPersonaServiceImplPort();

    	((BindingProvider)personaService).getRequestContext().put(BindingProvider.USERNAME_PROPERTY, "admin");
		((BindingProvider)personaService).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, "admin");
        
        List<Persona> personas = personaService.listarPersonas();

        for (Persona persona : personas) {
            System.out.println("Persona: " + persona.getNombre() + " " + persona.getApePaterno());
        }

        System.out.println("\nFin Servicio Listar Personas WS");
    }
}

