package test;

import java.util.List;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;

import domain.Persona;

public class TestClienteRS {

	public static void main(String[] args) {
		
		Client client = Client.create();

		client.addFilter(new HTTPBasicAuthFilter("admin", "admin"));
		
		/**********************
		 * Recuperar una persona
		 *********************/
		WebResource web = client
				.resource("http://localhost:8080/sistema-sga/webservice/personas/1");

		Persona persona = web.get(Persona.class);
		System.out.println("La persona es: " + persona.getNombre() + " "
				+ persona.getApePaterno());

		System.out.println();

		/*******************
		 * Agregar una persona
		 ******************/
		web = client
				.resource("http://localhost:8080/sistema-sga/webservice/personas");
		Persona nuevaPersona = new Persona();
		nuevaPersona.setNombre("Ricardo");
		nuevaPersona.setApePaterno("Gonzalez");
		nuevaPersona.setEmail("rgonzalez@mail.com");

		ClientResponse response = web.post(ClientResponse.class, nuevaPersona);

		System.out.println("El c�digo de respuesta en la inserci�n fue: "
				+ response.getStatus());

		if (response.getStatus() == 200) {
			Persona per = response.getEntity(Persona.class);
			System.out.println("Nueva persona: " + per.getIdPersona() + " "
					+ per.getNombre());
		}

		System.out.println();

		/*********************
		 * Modificar una persona
		 ********************/
		web = client
				.resource("http://localhost:8080/sistema-sga/webservice/personas/1");
		Persona personaModificada = persona;// persona recuperada anteriormente
		personaModificada.setNombre("Juan");
		personaModificada.setApePaterno("Perez");
		personaModificada.setEmail("jperez@mail.com");

		response = web.put(ClientResponse.class, personaModificada);

		System.out.println("El c�digo de respuesta de la modificaci�n fue: "
				+ response.getStatus());

		if (response.getStatus() == 200) {
			Persona per = response.getEntity(Persona.class);
			System.out.println("Nueva persona: " + per.getIdPersona() + " "
					+ per.getNombre());
		}

		System.out.println();

		/********************
		 * Eliminar una persona
		 *******************/
		WebResource wr = client
				.resource("http://localhost:8080/sistema-sga/webservice/personas/32");

		response = wr.delete(ClientResponse.class);
		
		System.out.println("El c�digo de respuesta de la eliminaci�n fue: "
				+ response.getStatus());
		
		if (response.getStatus() == 404) {
			System.out.println("La persona a eliminar NO existe");
		} else {
			System.out.println("La persona fue eliminada con �xito");
		}

		/********************
		 * Listar todas las Personas
		 *******************/
		web = client
				.resource("http://localhost:8080/sistema-sga/webservice/personas");

		List<Persona> personas = web.get(new GenericType<List<Persona>>() {
		});

		for (Persona p : personas) {
			System.out.println(p.getIdPersona() + " " + p.getNombre());
		}

		System.out.println();

	}
}
