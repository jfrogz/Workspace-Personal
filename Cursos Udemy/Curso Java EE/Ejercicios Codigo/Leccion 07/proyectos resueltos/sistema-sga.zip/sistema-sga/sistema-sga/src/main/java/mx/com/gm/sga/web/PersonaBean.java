package mx.com.gm.sga.web;

import java.security.Principal;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import mx.com.gm.sga.domain.Persona;
import mx.com.gm.sga.servicio.PersonaService;

import org.primefaces.event.RowEditEvent;

@ManagedBean
@RequestScoped
public class PersonaBean {
	@EJB
	private PersonaService personaService;
	List<Persona> personas;

	public PersonaBean() {
	}

	@PostConstruct
	public void inicializar() {
		personas = personaService.listarPersonas();
	}

	public void editListener(RowEditEvent event) {
		Persona persona = (Persona) event.getObject();
		personaService.modificarPersona(persona);
	}

	public List<Persona> getPersonas() {
		return personas;
	}

	public void setPersonas(List<Persona> personas) {
		this.personas = personas;
	}
	
	public void mostrarUsuario(ActionEvent e){
		System.out.println("Impresion del rol del usuario");
		
		String rol = "ROLE_ADMIN";
		
		boolean isRol =FacesContext.getCurrentInstance().getExternalContext().isUserInRole( rol );
		
		Principal principal = FacesContext.getCurrentInstance().getExternalContext().getUserPrincipal();
		
		String usuarioRemoto = FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
		
		System.out.println("Esta en rol " + rol + ": " + isRol);
		
		System.out.println("Usuario:" + principal.getName());
		
		System.out.println("Usuario remoto:" + usuarioRemoto);
			
	}
}