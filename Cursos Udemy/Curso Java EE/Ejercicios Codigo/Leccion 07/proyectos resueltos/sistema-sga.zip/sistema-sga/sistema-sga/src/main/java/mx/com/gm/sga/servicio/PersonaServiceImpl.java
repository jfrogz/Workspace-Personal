package mx.com.gm.sga.servicio;

import java.security.Principal;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.jws.WebService;

import mx.com.gm.sga.domain.Persona;
import mx.com.gm.sga.eis.PersonaDao;

@Stateless
@WebService(endpointInterface = "mx.com.gm.sga.servicio.PersonaServiceWS")
@DeclareRoles({ "ROLE_ADMIN", "ROLE_USER" })
@RolesAllowed({ "ROLE_ADMIN", "ROLE_USER" })
public class PersonaServiceImpl implements PersonaServiceRemote,
		PersonaService, PersonaServiceWS {

	@Resource
	private SessionContext contexto;

	@EJB
	private PersonaDao personaDao;

	public List<Persona> listarPersonas() {
		return personaDao.findAllPersonas();
	}

	public Persona encontrarPersonaPorId(Persona persona) {
		return personaDao.findPersonaById(persona);
	}

	public Persona econtrarPersonaPorEmail(Persona persona) {
		return personaDao.findPersonaByEmail(persona);
	}

	public void registrarPersona(Persona persona) {
		personaDao.insertPersona(persona);
	}

	public void modificarPersona(Persona persona) {
		try {
			personaDao.updatePersona(persona);
		} catch (Throwable t) {
			contexto.setRollbackOnly();
		}
	}

	@RolesAllowed("ROLE_ADMIN")
	public void eliminarPersona(Persona persona) {
		personaDao.deletePersona(persona);
	}

	public void ejemploSeguridadProgramatica() {
		
		//Imprimimos el nombre del usuario
		Principal principal = contexto.getCallerPrincipal();
		System.out.println("Nombre del usuario: " + principal.getName());
		
		//Restringimos la ejecuci�n restante del m�todo
		
		if (contexto.isCallerInRole("ROLE_ADMIN")) {
			System.out.println("SI tienes permiso de ejecutar este m�todo");
		} else {
			throw new SecurityException(
					"No cuentas con los permisos para ejecutar el m�todo");
		}
	}

}
