# Spring MVC 4 Hello World Example with XML Configurations, Maven, and Thymeleaf

## Guide
https://hellokoding.com/spring-mvc-4-hello-world-example-with-xml-configuration-maven-and-thymeleaf/

## Prerequisites
- JDK 1.8 or later

- Maven 3 or later

## Stack
- Spring MVC 4

- Thymeleaf

## Run
`mvn jetty:run`

